/*
 * Date: 2015/08/13
 * Comp: ADLINK
 * Desc: This example performs PXIe-9529 synchronization. Two PXIe-9529 (both of Slave) are needed and shoule be attached in PXIe system.
 *       Note that an additional Timing Borad is needed.
 *       [Start Trigger Synchronization Technique]
 *       Configures start trigger of Slave to be TRIG_BUS[5], so the AI operation of Slave will be started when the TRIG_BUS[5] is asserted.
 *       [Timebase Synchronization Technique]
 *       Configures timebase of Master to be PXIe_CLK100.
 *       Also configures timebase of Slave to be PXIe_CLK100, so the slave can refer the same timebase with Master.
 *       [PDN SYNC Synchronization Technique]
 *       Configures PDN SYNC path of Master and Slave to be TRIG_BUS[1], and then PDN SYNC will be ready when TRIG_BUS[1] is asserted.
 */
#include "pxie9529_multiple_device_sync_no_master.h"

const unsigned int dw_num_of_slaves = 2;

static DEVICE_CONFIG m_slave[dw_num_of_slaves];

HANDLE h_ai_done_event_slave[dw_num_of_slaves] = {NULL, };

// Callback function for Slave AI operation is complete
// Note: That the callback function can't pass arguments. So multiple function instances are needed if there are multiple slaves to be used.
//       And the slave structure should be matched with the corresponding one. (e.g. ai_done_cbfunc_slave_1() for m_slave[1])
static void ai_done_cbfunc_slave_0()
{
    printf("\nSlave[0] AI acquisition is complete!");

    // Set event
    if (h_ai_done_event_slave[0])
    {
        SetEvent(h_ai_done_event_slave[0]);
    }
}

static void ai_done_cbfunc_slave_1()
{
    printf("\nSlave[1] AI acquisition is complete!");

    // Set event
    if (h_ai_done_event_slave[1])
    {
        SetEvent(h_ai_done_event_slave[1]);
    }
}

// Callback function for Slave AI buffer ready event
// Note: That the callback function can't pass arguments. So multiple function instances are needed if there are multiple slaves to be used.
//       And the slave structure should be matched with the corresponding one. (e.g. ai_buf_ready_cbfunc_slave_1() for m_slave[1])
static void ai_buf_ready_cbfunc_slave_0()
{
    if (m_slave[0].is_buf_ready_evt_set)
    {
        m_slave[0].buf_ready_cnt += 1;
        printf("\nSlave[0] buffer half ready, ready count: %d", m_slave[0].buf_ready_cnt);

        // Convert AI raw data to scaled data, it depends on the setting of channel range.
        DSA_AI_ContVScale(m_slave[0].card_handle, m_slave[0].chnl_range, m_slave[0].raw_data_buf_alignment[m_slave[0].buf_ready_idx], m_slave[0].scale_data_buf, m_slave[0].buf_size);

        m_slave[0].buf_ready_idx += 1;
        m_slave[0].buf_ready_idx %= 2;

        // Write to file
        for (unsigned int vi = 0; vi < m_slave[0].buf_size / m_slave[0].chnl_cnt; ++ vi)
        {
            for (unsigned int vj = 0; vj < m_slave[0].chnl_cnt; ++ vj)
            {
                if (m_slave[0].file_writer)
                {
                    fprintf(m_slave[0].file_writer, "%.8f,", m_slave[0].scale_data_buf[vi * m_slave[0].chnl_cnt + vj]);
                }
            }
            fprintf(m_slave[0].file_writer, "\n");
        }

        // Tell DSA-DASK that the ready buffer is handled
        DSA_AI_AsyncDblBufferHandled(m_slave[0].card_handle);
    }
}

static void ai_buf_ready_cbfunc_slave_1()
{
    if (m_slave[1].is_buf_ready_evt_set)
    {
        m_slave[1].buf_ready_cnt += 1;
        printf("\nSlave[1] buffer half ready, ready count: %d", m_slave[1].buf_ready_cnt);

        // Convert AI raw data to scaled data, it depends on the setting of channel range.
        DSA_AI_ContVScale(m_slave[1].card_handle, m_slave[1].chnl_range, m_slave[1].raw_data_buf_alignment[m_slave[1].buf_ready_idx], m_slave[1].scale_data_buf, m_slave[1].buf_size);

        m_slave[1].buf_ready_idx += 1;
        m_slave[1].buf_ready_idx %= 2;

        // Write to file
        for (unsigned int vi = 0; vi < m_slave[1].buf_size / m_slave[1].chnl_cnt; ++ vi)
        {
            for (unsigned int vj = 0; vj < m_slave[1].chnl_cnt; ++ vj)
            {
                if (m_slave[1].file_writer)
                {
                    fprintf(m_slave[1].file_writer, "%.8f,", m_slave[1].scale_data_buf[vi * m_slave[1].chnl_cnt + vj]);
                }
            }
            fprintf(m_slave[1].file_writer, "\n");
        }

        // Tell DSA-DASK that the ready buffer is handled
        DSA_AI_AsyncDblBufferHandled(m_slave[1].card_handle);
    }
}
unsigned long m_ai_cbfunc_slave[dw_num_of_slaves][2] =
{
    {(unsigned long)ai_done_cbfunc_slave_0, (unsigned long)ai_buf_ready_cbfunc_slave_0},
    {(unsigned long)ai_done_cbfunc_slave_1, (unsigned long)ai_buf_ready_cbfunc_slave_1}
};

int main(int argc, char **argv)
{
    printf("This example performs PXIe-9529 synchronization without Master.\n");
    printf("Two PXIe-9529 are needed and shoule be attached in PXIe system.\n");
    printf("Note that an additional PXI/PXIe Timing Board is needed to\n");
    printf("fire pulse to TRIG_BUS[5] for start trigger and to TRIG_BUS[1] for PDN SYNC.\n\n");
    getchar();

    // Initialize configuration structure
    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        fn_init_slave_struct(&m_slave[vi], vi);
    }

    // Configure device by console input
    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        fn_config_slave_struct(&m_slave[vi]);
    }

    // Step 1. Register Device (Slave)
    short result = fn_register_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 1;
    }

    // Step 2. Configure Synchronization Settings (Slave)
    result = fn_config_sync_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 2;
    }

    // Step 3. Wait for PDN SYNC done (Slave)
    result = fn_start_sync_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 3;
    }

    // Step 4.1 Configure AI Function - Channel (Slave)
    result = fn_config_ai_channel_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 4;
    }

    // Step 4.2 Configure AI Function - DMA Transfer Buffer (Slave)
    result = fn_config_ai_buffer_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 5;
    }

    // Step 4.3 Configure AI Function - Event Callback (Slave)
    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        m_slave[vi].callback_ai_done = (unsigned long)m_ai_cbfunc_slave[vi][0];
        m_slave[vi].callback_ai_buf_ready = (unsigned long)m_ai_cbfunc_slave[vi][1];
    }
    result = fn_config_ai_event_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 6;
    }

    printf("\nPress 'Enter' to start AI operation...");
    getchar();

    // Step 5. Start AI Acquisition
    result = fn_start_ai_acquisition_master_slave(NULL, dw_num_of_slaves, m_slave);
    if (result < 0)
    {
        fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
        return 7;
    }

    // Press 'Enter' to stop
    getchar();

    // Clear AI setting
    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        DSA_AI_AsyncClear(m_slave[vi].card_handle, &m_slave[vi].access_cnt);
        m_slave[vi].is_op_run = 0;
    }

    // Wait for that ai_done_cbfunc() is complete
    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        // Note that event instance should be created for each slaves. In this example, we do not consider it.
        if (h_ai_done_event_slave[vi])
        {
            WaitForSingleObject(h_ai_done_event_slave[vi], 5000);
        }
    }

    for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
    {
        printf("\nSlave[%d] AI data is stored in file %s", vi, m_slave[vi].file_name);
    }

    // Exit program
    fn_exit_handler(NULL, dw_num_of_slaves, m_slave);
    return 0;
}
