#include "pxie9529_multiple_device_sync.h"

static int _get_console_input(int default_value)
{
    static char sz[MAX_PATH];
    fgets(sz, MAX_PATH, stdin);

    int return_value = default_value;
    if (sz[0] != 0x0a)
    {
        sscanf(sz, "%d", &return_value);
    }

    return return_value;
}

static double _get_console_input(double default_value)
{
    static char sz[MAX_PATH];
    fgets(sz, MAX_PATH, stdin);

    double return_value = default_value;
    if (sz[0] != 0x0a)
    {
        sscanf(sz, "%lf", &return_value);
    }

    return return_value;
}

void fn_exit_handler(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    // Master
    if (NULL != pm_master_device_config)
    {
        // Async Clear
        if (pm_master_device_config->is_op_run)
        {
            DSA_AI_AsyncClear(pm_master_device_config->card_handle, &pm_master_device_config->access_cnt);
        }

        // Close file
        if (pm_master_device_config->is_file_open)
        {
            fclose(pm_master_device_config->file_writer);
        }

        // Reset done event
        if (pm_master_device_config->is_done_evt_set)
        {
            DSA_AI_EventCallBack(pm_master_device_config->card_handle, 0, AIEnd, NULL);
        }

        // Reset done event
        if (pm_master_device_config->is_done_evt_set)
        {
            DSA_AI_EventCallBack(pm_master_device_config->card_handle, 0, DBEvent, NULL);
        }

        // Reset buffer
        if (pm_master_device_config->is_set_buf)
        {
            DSA_AI_ContBufferReset(pm_master_device_config->card_handle);
            free(pm_master_device_config->raw_data_buf[0]);
            free(pm_master_device_config->raw_data_buf[1]);
        }

        // Disable synchronization
        if (pm_master_device_config->is_pdn_sync)
        {
            DSA_SYN_ConfigMultiCard(pm_master_device_config->card_handle, P9529_SYN_Disable, pm_master_device_config->pdn_sync_path);
        }

        // Disconnect trigger out (only Master)
        if (pm_master_device_config->is_trig_out_connected)
        {
            DSA_TRG_SourceDisConn(pm_master_device_config->card_handle, pm_master_device_config->trig_out);
        }

        // Release device
        if (pm_master_device_config->is_reg_dev)
        {
            DSA_Release_Card(pm_master_device_config->card_handle);
        }
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            // Async Clear
            if (pm_slaves_device_config[vi].is_op_run)
            {
                DSA_AI_AsyncClear(pm_slaves_device_config[vi].card_handle, &pm_slaves_device_config[vi].access_cnt);
            }

            // Close file
            if (pm_slaves_device_config[vi].is_file_open)
            {
                fclose(pm_slaves_device_config[vi].file_writer);
            }

            // Reset done event
            if (pm_slaves_device_config[vi].is_done_evt_set)
            {
                DSA_AI_EventCallBack(pm_slaves_device_config[vi].card_handle, 0, AIEnd, NULL);
            }

            // Reset done event
            if (pm_slaves_device_config[vi].is_done_evt_set)
            {
                DSA_AI_EventCallBack(pm_slaves_device_config[vi].card_handle, 0, DBEvent, NULL);
            }

            // Reset buffer
            if (pm_slaves_device_config[vi].is_set_buf)
            {
                DSA_AI_ContBufferReset(pm_slaves_device_config[vi].card_handle);
                free(pm_slaves_device_config[vi].raw_data_buf[0]);
                free(pm_slaves_device_config[vi].raw_data_buf[1]);
            }

            // Disable synchronization
            if (pm_slaves_device_config[vi].is_pdn_sync)
            {
                DSA_SYN_ConfigMultiCard(pm_slaves_device_config[vi].card_handle, P9529_SYN_Disable, pm_slaves_device_config[vi].pdn_sync_path);
            }

            // Release device
            if (pm_slaves_device_config[vi].is_reg_dev)
            {
                DSA_Release_Card(pm_slaves_device_config[vi].card_handle);
            }
        }
    }

    printf("\n\nPress any key to exit...");
    getchar();
}

void fn_init_master_struct(P_DEVICE_CONFIG pm_device_config, unsigned int dw_card_idx)
{
    if (NULL != pm_device_config)
    {
        // Device configuration & status variables
        pm_device_config->is_reg_dev = 0;
        pm_device_config->card_type = PXI_9529;
        pm_device_config->card_num = dw_card_idx;
        pm_device_config->card_handle = 0;

        // Timebase configuration variables
        pm_device_config->timebase_src = P9529_PXIE100M; // PXIe 100MHz Clock
        pm_device_config->sample_rate = 48000;
        pm_device_config->actual_rate = 48000;

        // Trigger configuration & status variables
        pm_device_config->trig_target = P9529_TRG_AI;
        pm_device_config->trig_config = P9529_TRG_MODE_POST | P9529_TRG_SRC_SOFT;
        pm_device_config->is_gen_sw_trig = 1;
        pm_device_config->is_set_ana_trig = 0;
        pm_device_config->retrig_count = 0;
        pm_device_config->trig_delay = 0;
        pm_device_config->trig_out = P9529_TRG_OUT_PXI_BUS5; // Export trigger to TRIG_BUS[5]
        pm_device_config->is_trig_out_connected = 0;

        // Analog trigger configuration variables
        pm_device_config->ana_trig_src = 0;
        pm_device_config->ana_trig_mode = 0;
        pm_device_config->ana_trig_threshold = 0;

        // PDN SYNC configuration & status variables
        pm_device_config->pdn_sync_type = P9529_SYN_MasterCard;
        pm_device_config->pdn_sync_path = P9529_SYN_PXI_BUS1;
        pm_device_config->pdn_sync_status = 0;
        pm_device_config->is_pdn_sync = 0;

        // Channel configuration variables
        pm_device_config->chnl_cnt = 8;
        pm_device_config->chnl_range = AD_B_10_V;
        pm_device_config->chnl_config = P9529_AI_PseDiff | P9529_AI_Coupling_DC;

        // Data buffer & file variables
        pm_device_config->chnl_sample_count = 65536;
        pm_device_config->all_data_count = pm_device_config->chnl_cnt * pm_device_config->chnl_sample_count;
        pm_device_config->buf_size = pm_device_config->all_data_count;
        pm_device_config->raw_data_buf[0] = NULL;
        pm_device_config->raw_data_buf[1] = NULL;
        pm_device_config->raw_data_buf_alignment[0] = NULL;
        pm_device_config->raw_data_buf_alignment[1] = NULL;
        pm_device_config->scale_data_buf = NULL;
        pm_device_config->buf_id_array[0] = NULL;
        pm_device_config->buf_id_array[1] = NULL;
        pm_device_config->is_set_buf = 0;
        pm_device_config->file_format = 0;
        sprintf(pm_device_config->file_name, "ai_data_master[9529#%d].csv", dw_card_idx);
        pm_device_config->file_writer = NULL;
        pm_device_config->is_file_open = 0;

        // AI opeation callback variables
        pm_device_config->callback_ai_done = 0;
        pm_device_config->callback_ai_buf_ready = 0;
        pm_device_config->is_done_evt_set = 0;
        pm_device_config->is_buf_ready_evt_set = 0;

        // AI operation status variables
        pm_device_config->is_op_run = 0;
        pm_device_config->access_cnt = 0;
        pm_device_config->buf_ready_idx = 0;
        pm_device_config->buf_ready_cnt = 0;
    }
}

void fn_init_slave_struct(P_DEVICE_CONFIG pm_device_config, unsigned int dw_card_idx)
{
    if (NULL != pm_device_config)
    {
        // Device configuration & status variables
        pm_device_config->is_reg_dev = 0;
        pm_device_config->card_type = PXI_9529;
        pm_device_config->card_num = dw_card_idx;
        pm_device_config->card_handle = 0;

        // Timebase configuration variables
        pm_device_config->timebase_src = P9529_PXIE100M; // PXIe 100MHz Clock
        pm_device_config->sample_rate = 48000;
        pm_device_config->actual_rate = 48000;

        // Trigger configuration & status variables
        pm_device_config->trig_target = P9529_TRG_AI;
        pm_device_config->trig_config = P9529_TRG_MODE_POST | P9529_TRG_SRC_PXI_BUS5; // Trigger source TRIG_BUS[5]
        pm_device_config->is_gen_sw_trig = 0;
        pm_device_config->is_set_ana_trig = 0;
        pm_device_config->retrig_count = 0;
        pm_device_config->trig_delay = 0;
        pm_device_config->trig_out = 0;
        pm_device_config->is_trig_out_connected = 0;

        // Analog trigger configuration variables
        pm_device_config->ana_trig_src = 0;
        pm_device_config->ana_trig_mode = 0;
        pm_device_config->ana_trig_threshold = 0;

        // PDN SYNC configuration & status variables
        pm_device_config->pdn_sync_type = P9529_SYN_SlaveCard;
        pm_device_config->pdn_sync_path = P9529_SYN_PXI_BUS1;
        pm_device_config->pdn_sync_status = 0;
        pm_device_config->is_pdn_sync = 0;

        // Channel configuration variables
        pm_device_config->chnl_cnt = 8;
        pm_device_config->chnl_range = AD_B_10_V;
        pm_device_config->chnl_config = P9529_AI_PseDiff | P9529_AI_Coupling_DC;

        // Data buffer & file variables
        pm_device_config->chnl_sample_count = 65536;
        pm_device_config->all_data_count = pm_device_config->chnl_cnt * pm_device_config->chnl_sample_count;
        pm_device_config->buf_size = pm_device_config->all_data_count;
        pm_device_config->raw_data_buf[0] = NULL;
        pm_device_config->raw_data_buf[1] = NULL;
        pm_device_config->raw_data_buf_alignment[0] = NULL;
        pm_device_config->raw_data_buf_alignment[1] = NULL;
        pm_device_config->scale_data_buf = NULL;
        pm_device_config->buf_id_array[0] = NULL;
        pm_device_config->buf_id_array[1] = NULL;
        pm_device_config->is_set_buf = 0;
        pm_device_config->file_format = 0;
        sprintf(pm_device_config->file_name, "ai_data_slave[9529#%d].csv", dw_card_idx);
        pm_device_config->file_writer = NULL;
        pm_device_config->is_file_open = 0;

        // AI opeation callback variables
        pm_device_config->callback_ai_done = 0;
        pm_device_config->callback_ai_buf_ready = 0;
        pm_device_config->is_done_evt_set = 0;
        pm_device_config->is_buf_ready_evt_set = 0;

        // AI operation status variables
        pm_device_config->is_op_run = 0;
        pm_device_config->access_cnt = 0;
        pm_device_config->buf_ready_idx = 0;
        pm_device_config->buf_ready_cnt = 0;
    }
}

void fn_config_master_struct(P_DEVICE_CONFIG pm_device_config)
{
    if (NULL != pm_device_config)
    {
        printf("\n");
        unsigned int dw_card_idx = pm_device_config->card_num;

        // AI channel
        printf("Master [9529#%d] number of channels? (1, 2, 4, 8): [8] ", dw_card_idx);
        pm_device_config->chnl_cnt = (unsigned short)_get_console_input(8);
        if (pm_device_config->chnl_cnt != 1 && pm_device_config->chnl_cnt != 2 && pm_device_config->chnl_cnt != 4 && pm_device_config->chnl_cnt != 8)
        {
            printf("Warning! Invalid number of channels. Force to set to 8.\n");
            pm_device_config->chnl_cnt = 8;
        }

        // AI channel range
        printf("Master [9529#%d] channel range? (0) B_10_V, (1) AD_B_1_V: [0] ", dw_card_idx);
        unsigned short tmp_chnl_range;
        tmp_chnl_range = (unsigned short)_get_console_input(0);
        switch (tmp_chnl_range)
        {
            case 0:
                pm_device_config->chnl_range = AD_B_10_V;
                break;
            case 1:
                pm_device_config->chnl_range = AD_B_1_V;
                break;
            default:
                printf("Warning! Invalid channel range. Force to set to B_10_V.\n");
                pm_device_config->chnl_range = AD_B_10_V;
        }

        //AI channel input type
        printf("Master [9529#%d] channel input type? (0) Differential, (1) Pseudo-Diff: [1] ", dw_card_idx);
        unsigned short tmp_chnl_config;
        tmp_chnl_config = (unsigned short)_get_console_input(1);
        switch (tmp_chnl_config)
        {
            case 0:
                pm_device_config->chnl_config = P9529_AI_Diff;
                break;
            case 1:
                pm_device_config->chnl_config = P9529_AI_PseDiff;
                break;
            default:
                printf("Warning! Invalid channel input type. Force to set to Pseudo-Diff.\n");
                pm_device_config->chnl_config = P9529_AI_PseDiff;
        }

        //AI channel input coupling
        printf("Master [9529#%d] channel input coupling? (0) DC, (1) AC, (2) IEPE Enabled: [0] ", dw_card_idx);
        tmp_chnl_config = (unsigned short)_get_console_input(0);
        switch (tmp_chnl_config)
        {
            case 0:
                pm_device_config->chnl_config |= P9529_AI_Coupling_DC;
                break;
            case 1:
                pm_device_config->chnl_config |= P9529_AI_Coupling_AC;
                break;
            case 2:
                pm_device_config->chnl_config |= P9529_AI_EnableIEPE;
                break;
            default:
                printf("Warning! Invalid channel input coupling. Force to set to DC Coupling.\n");
                pm_device_config->chnl_config |= P9529_AI_Coupling_DC;
        }

        // Trigger source
        printf("Master [9529#%d] trigger source? (0) Software, (1) External_Digital: [0] ", dw_card_idx);
        unsigned short tmp_trig_source;
        tmp_trig_source = (unsigned short)_get_console_input(0);
        switch (tmp_trig_source)
        {
            case 0:
                pm_device_config->is_gen_sw_trig = 1;
                pm_device_config->trig_config = P9529_TRG_MODE_POST | P9529_TRG_SRC_SOFT;
                break;
            case 1:
                pm_device_config->is_gen_sw_trig = 0;
                pm_device_config->trig_config = P9529_TRG_MODE_POST | P9529_TRG_SRC_EXTD;
                break;
            default:
                printf("Warning! Invalid trigger source. Force to set to Software.\n");
                pm_device_config->is_gen_sw_trig = 1;
                pm_device_config->trig_config = P9529_TRG_MODE_POST | P9529_TRG_SRC_SOFT;
        }

        // Sample rate
        unsigned int tmp_sample_rate_min = 8000;
        unsigned int tmp_sample_rate_max = 192000;
        printf("Master [9529#%d] sample rate? (%d ~ %d): [48000] ", dw_card_idx, tmp_sample_rate_min, tmp_sample_rate_max);
        pm_device_config->sample_rate = (double)_get_console_input(48000.0);
        if (pm_device_config->sample_rate < tmp_sample_rate_min || pm_device_config->sample_rate > tmp_sample_rate_max)
        {
            printf("Warning! Invalid sample rate. Force to set to 48000.\n");
            pm_device_config->sample_rate = 48000;
        }

        // Sample count
        printf("Master [9529#%d] sample count (per channel / per buffer)? [65536] ", dw_card_idx);
        pm_device_config->chnl_sample_count = (unsigned long)_get_console_input(65536);
        pm_device_config->all_data_count = pm_device_config->chnl_sample_count * pm_device_config->chnl_cnt;
        if (pm_device_config->all_data_count == 0 || pm_device_config->all_data_count % 2 != 0)
        {
            printf("Warning! Invalid sample count. Force to set to 65536.\n");
            pm_device_config->chnl_sample_count = 65536;
            pm_device_config->all_data_count = pm_device_config->chnl_sample_count * pm_device_config->chnl_cnt;
        }

        pm_device_config->buf_size = pm_device_config->all_data_count;
    }
}

void fn_config_slave_struct(P_DEVICE_CONFIG pm_device_config)
{
    if (NULL != pm_device_config)
    {
        printf("\n");
        unsigned int dw_card_idx = pm_device_config->card_num;

        // AI channel
        printf("Slave [9529#%d] number of channels? (1, 2, 4, 8): [8] ", dw_card_idx);
        pm_device_config->chnl_cnt = (unsigned short)_get_console_input(8);
        if (pm_device_config->chnl_cnt != 1 && pm_device_config->chnl_cnt != 2 && pm_device_config->chnl_cnt != 4 && pm_device_config->chnl_cnt != 8)
        {
            printf("Warning! Invalid number of channels. Force to set to 8.\n");
            pm_device_config->chnl_cnt = 8;
        }

        // AI channel range
        printf("Slave [9529#%d] channel range? (0) B_10_V, (1) AD_B_1_V: [0] ", dw_card_idx);
        unsigned short tmp_chnl_range;
        tmp_chnl_range = (unsigned short)_get_console_input(0);
        switch (tmp_chnl_range)
        {
            case 0:
                pm_device_config->chnl_range = AD_B_10_V;
                break;
            case 1:
                pm_device_config->chnl_range = AD_B_1_V;
                break;
            default:
                printf("Warning! Invalid channel range. Force to set to B_10_V.\n");
                pm_device_config->chnl_range = AD_B_10_V;
        }

        //AI channel input type
        printf("Slave [9529#%d] channel input type? (0) Differential, (1) Pseudo-Diff: [1] ", dw_card_idx);
        unsigned short tmp_chnl_config;
        tmp_chnl_config = (unsigned short)_get_console_input(1);
        switch (tmp_chnl_config)
        {
            case 0:
                pm_device_config->chnl_config = P9529_AI_Diff;
                break;
            case 1:
                pm_device_config->chnl_config = P9529_AI_PseDiff;
                break;
            default:
                printf("Warning! Invalid channel input type. Force to set to Pseudo-Diff.\n");
                pm_device_config->chnl_config = P9529_AI_PseDiff;
        }

        //AI channel input coupling
        printf("Slave [9529#%d] channel input coupling? (0) DC, (1) AC, (2) IEPE Enabled: [0] ", dw_card_idx);
        tmp_chnl_config = (unsigned short)_get_console_input(0);
        switch (tmp_chnl_config)
        {
            case 0:
                pm_device_config->chnl_config |= P9529_AI_Coupling_DC;
                break;
            case 1:
                pm_device_config->chnl_config |= P9529_AI_Coupling_AC;
                break;
            case 2:
                pm_device_config->chnl_config |= P9529_AI_EnableIEPE;
                break;
            default:
                printf("Warning! Invalid channel input coupling. Force to set to DC Coupling.\n");
                pm_device_config->chnl_config |= P9529_AI_Coupling_DC;
        }

        // Sample rate
        unsigned int tmp_sample_rate_min = 8000;
        unsigned int tmp_sample_rate_max = 192000;
        printf("Slave [9529#%d] sample rate? (%d ~ %d): [48000] ", dw_card_idx, tmp_sample_rate_min, tmp_sample_rate_max);
        pm_device_config->sample_rate = (double)_get_console_input(48000.0);
        if (pm_device_config->sample_rate < tmp_sample_rate_min || pm_device_config->sample_rate > tmp_sample_rate_max)
        {
            printf("Warning! Invalid sample rate. Force to set to 48000.\n");
            pm_device_config->sample_rate = 48000;
        }

        // Sample count
        printf("Slave [9529#%d] sample count (per channel / per buffer)? [65536] ", dw_card_idx);
        pm_device_config->chnl_sample_count = (unsigned long)_get_console_input(65536);
        pm_device_config->all_data_count = pm_device_config->chnl_sample_count * pm_device_config->chnl_cnt;
        if (pm_device_config->all_data_count == 0 || pm_device_config->all_data_count % 2 != 0)
        {
            printf("Warning! Invalid sample count. Force to set to 65536.\n");
            pm_device_config->chnl_sample_count = 65536;
            pm_device_config->all_data_count = pm_device_config->chnl_sample_count * pm_device_config->chnl_cnt;
        }

        pm_device_config->buf_size = pm_device_config->all_data_count;
    }
}

short fn_register_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    printf("\nRegistering devices... ");

    // Register a specified device, it sets and initializes all related variables and necessary resources.
    // This function must be called before calling any other functions to control the device.
    // Remember to call DSA_Release_Card() to release all allocated resources.

    // Master
    if (NULL != pm_master_device_config)
    {
        short result = DSA_Register_Card(pm_master_device_config->card_type, pm_master_device_config->card_num);
        if (result < 0)
        {
            printf("\nFalied to perform DSA_Register_Card() for Master, error: %d", result);
            return -1;
        }
        pm_master_device_config->card_handle = (unsigned short)result;
        pm_master_device_config->is_reg_dev = 1;
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            short result = DSA_Register_Card(pm_slaves_device_config[vi].card_type, pm_slaves_device_config[vi].card_num);
            if (result < 0)
            {
                printf("\nFalied to perform DSA_Register_Card() for Slave[%d], error: %d", vi, result);
                return -11;
            }
            pm_slaves_device_config[vi].card_handle = (unsigned short)result;
            pm_slaves_device_config[vi].is_reg_dev = 1;
        }
    }

    printf("done\n");
    return 0;
}

short fn_config_sync_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    printf("\nConfiguring synchronization...");
    printf("\nIt may take a few seconds to initial ADC, please wait... ");

    // Master
    if (NULL != pm_master_device_config)
    {
        // Configure Master timebase
        // This function may take a few seconds to initial and adjust ADC settings
        short result = DSA_ConfigSpeedRate(pm_master_device_config->card_handle, DAQ_AI, pm_master_device_config->timebase_src, pm_master_device_config->sample_rate, &pm_master_device_config->actual_rate);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_ConfigSpeedRate() for Master, error: %d", result);
            return -1;
        }

        // Configure Master trigger out
        result = DSA_TRG_SourceConn(pm_master_device_config->card_handle, pm_master_device_config->trig_out);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_TRG_SourceConn() for Master, error: %d", result);
            return -2;
        }
        pm_master_device_config->is_trig_out_connected = 1;

        // Configure Master trigger
        result = DSA_TRG_Config(pm_master_device_config->card_handle, pm_master_device_config->trig_target, pm_master_device_config->trig_config, pm_master_device_config->retrig_count, pm_master_device_config->trig_delay);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_TRG_Config() for Master, error: %d", result);
            return -3;
        }

        // Configure Master PDN sync
        result = DSA_SYN_ConfigMultiCard(pm_master_device_config->card_handle, pm_master_device_config->pdn_sync_type, pm_master_device_config->pdn_sync_path);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_TRG_Config() for Master, error: %d", result);
            return -4;
        }
        pm_master_device_config->is_pdn_sync = 1;
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            // Configure Slave timebase
            // This function may take a few seconds to initial and adjust ADC settings
            short result = DSA_ConfigSpeedRate(pm_slaves_device_config[vi].card_handle, DAQ_AI, pm_slaves_device_config[vi].timebase_src, pm_slaves_device_config[vi].sample_rate, &pm_slaves_device_config[vi].actual_rate);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_ConfigSpeedRate() for Slave, error: %d", result);
                return -11;
            }

            // Configure Slave trigger
            result = DSA_TRG_Config(pm_slaves_device_config[vi].card_handle, pm_slaves_device_config[vi].trig_target, pm_slaves_device_config[vi].trig_config, pm_slaves_device_config[vi].retrig_count, pm_slaves_device_config[vi].trig_delay);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_TRG_Config() for Slave, error: %d", result);
                return -13;
            }

            // Configure Slave PDN sync
            result = DSA_SYN_ConfigMultiCard(pm_slaves_device_config[vi].card_handle, pm_slaves_device_config[vi].pdn_sync_type, pm_slaves_device_config[vi].pdn_sync_path);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_TRG_Config() for Slave, error: %d", result);
                return -14;
            }
            pm_slaves_device_config[vi].is_pdn_sync = 1;
        }
    }

    printf("done\n");
    return 0;
}

short fn_start_sync_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    printf("\nStarting synchronization...");

    // Check Master SYNC status
    if (NULL != pm_master_device_config)
    {
        do {
            Sleep(1);
            DSA_SYN_CheckMultiCardStatus(pm_master_device_config->card_handle, &pm_master_device_config->pdn_sync_status);
        } while ((pm_master_device_config->pdn_sync_status & P9529_SYN_IsMasterCard) == 0 || (pm_master_device_config->pdn_sync_status & P9529_SYN_IsMultiCard) == 0);
    }

    // Check Slaves SYNC status
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            do {
                Sleep(1);
                DSA_SYN_CheckMultiCardStatus(pm_slaves_device_config[vi].card_handle, &pm_slaves_device_config[vi].pdn_sync_status);
            } while ((pm_slaves_device_config[vi].pdn_sync_status & P9529_SYN_IsMultiCard) == 0);
        }
    }

    // Start Synchronization (only Master)
    if (NULL != pm_master_device_config)
    {
        short result = DSA_SYN_SyncStart(pm_master_device_config->card_handle);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_SYN_SyncStart() for Slave, error: %d", result);
            return -1;
        }
    }

    // Wait Master SYNC status to Sync Done
    if (NULL != pm_master_device_config)
    {
        int wait_loop = 0;
        do {
            wait_loop += 1;
            if (wait_loop > 1000)
            {
                printf("\nFalied to wait Master Sync Done");
                return -2;
            }
            Sleep(1);
            DSA_SYN_CheckMultiCardStatus(pm_master_device_config->card_handle, &pm_master_device_config->pdn_sync_status);
        } while ((pm_master_device_config->pdn_sync_status & P9529_SYN_IsPDNSyncReady) == 0);
    }

    // Wait Slaves SYNC status to Sync Done
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            int wait_loop = 0;
            do {
                wait_loop += 1;
                if (wait_loop > 1000)
                {
                    printf("\nFalied to wait Slave Sync Done");
                    return -12;
                }
                Sleep(1);
                DSA_SYN_CheckMultiCardStatus(pm_slaves_device_config[vi].card_handle, &pm_slaves_device_config[vi].pdn_sync_status);
            } while ((pm_slaves_device_config[vi].pdn_sync_status & P9529_SYN_IsPDNSyncReady) == 0);
        }
    }

    printf("done\n");
    return 0;
}

short fn_config_ai_channel_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    // Configure AI channels for a registered device
    // Note that the channel input range and input configuration can be set to different for each channel (This example sets the same setting for all enabled channels).

    // Master
    if (NULL != pm_master_device_config)
    {
        unsigned char tmp_chnl_mode = 0;
        for (int vi = 0; vi < 8; ++ vi)
        {
            if (vi < pm_master_device_config->chnl_cnt)
            {
                tmp_chnl_mode = 1; // This channel will be enabled
            }
            else
            {
                tmp_chnl_mode = 0; // This channel will be disabled
            }
            short result = DSA_AI_9529_ConfigChannel(pm_master_device_config->card_handle, vi, tmp_chnl_mode, pm_master_device_config->chnl_range, pm_master_device_config->chnl_config);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_AI_9529_ConfigChannel() for Master, error: %d", result);
                return -1;
            }
        }
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            unsigned char tmp_chnl_mode = 0;
            for (unsigned short vj = 0; vj < 8; ++ vj)
            {
                if (vj < pm_slaves_device_config[vi].chnl_cnt)
                {
                    tmp_chnl_mode = 1; // This channel will be enabled
                }
                else
                {
                    tmp_chnl_mode = 0; // This channel will be disabled
                }
                short result = DSA_AI_9529_ConfigChannel(pm_slaves_device_config[vi].card_handle, vj, tmp_chnl_mode, pm_slaves_device_config[vi].chnl_range, pm_slaves_device_config[vi].chnl_config);
                if (result != NoError)
                {
                    printf("\nFalied to perform DSA_AI_9529_ConfigChannel() for Slave, error: %d", result);
                    return -11;
                }
            }
        }
    }

    return 0;
}

short fn_config_ai_buffer_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    // Enable double-buffer mode
    // DSA-Dask provides a technique called double-buffer mode to perform continuous AI operation.
    // Please refer DSA-DASK User Manual section 5.2 for details.

    // Master
    if (NULL != pm_master_device_config)
    {
        short result = DSA_AI_AsyncDblBufferMode(pm_master_device_config->card_handle, 1);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_AI_AsyncDblBufferMode() for Master, error: %d", result);
            return -1;
        }
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            short result = DSA_AI_AsyncDblBufferMode(pm_slaves_device_config[vi].card_handle, 1);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_AI_AsyncDblBufferMode() for Slave, error: %d", result);
                return -11;
            }
        }
    }

    // Setup buffer for data transfer
    // Note: For 9529, the memory address of performing DMA transfer should be 16 alignment.

    // Master
    if (NULL != pm_master_device_config)
    {
        pm_master_device_config->raw_data_buf[0] = (unsigned long *)malloc(sizeof(unsigned long) * pm_master_device_config->buf_size + 16);
        pm_master_device_config->raw_data_buf[1] = (unsigned long *)malloc(sizeof(unsigned long) * pm_master_device_config->buf_size + 16);

        // Adjust memory address for 16 alignment
        pm_master_device_config->raw_data_buf_alignment[0] = (unsigned long *)((unsigned long)pm_master_device_config->raw_data_buf[0] & 0xfffffff0);
        if ((unsigned long)pm_master_device_config->raw_data_buf[0] & 0xf)
        {
            pm_master_device_config->raw_data_buf_alignment[0] = (unsigned long *)((unsigned long)pm_master_device_config->raw_data_buf_alignment[0] + 16);
        }
        pm_master_device_config->raw_data_buf_alignment[1] = (unsigned long *)((unsigned long)pm_master_device_config->raw_data_buf[1] & 0xfffffff0);
        if ((unsigned long)pm_master_device_config->raw_data_buf[1] & 0xf)
        {
            pm_master_device_config->raw_data_buf_alignment[1] = (unsigned long *)((unsigned long)pm_master_device_config->raw_data_buf_alignment[1] + 16);
        }

        pm_master_device_config->scale_data_buf = (double *)malloc(sizeof(double) * pm_master_device_config->buf_size);

        for (int vj = 0; vj < 2; ++ vj)
        {
            short result = DSA_AI_ContBufferSetup(pm_master_device_config->card_handle, pm_master_device_config->raw_data_buf_alignment[vj], pm_master_device_config->buf_size, &pm_master_device_config->buf_id_array[vj]);
            if (result != NoError)
            {
                if (vj != 0)
                {
                    // Reset buffer
                    DSA_AI_ContBufferReset(pm_master_device_config->card_handle);
                }
                for (int vk = 0; vk < vj; ++ vk)
                {
                    free(pm_master_device_config->raw_data_buf[vk]);
                }
                free(pm_master_device_config->scale_data_buf);
                printf("\nFalied to perform DSA_AI_ContBufferSetup() for Master, error: %d", result);
                return -2;
            }
        }
        pm_master_device_config->is_set_buf = 1;
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            pm_slaves_device_config[vi].raw_data_buf[0] = (unsigned long *)malloc(sizeof(unsigned long) * pm_slaves_device_config[vi].buf_size + 16);
            pm_slaves_device_config[vi].raw_data_buf[1] = (unsigned long *)malloc(sizeof(unsigned long) * pm_slaves_device_config[vi].buf_size + 16);

            // Adjust memory address for 16 alignment
            pm_slaves_device_config[vi].raw_data_buf_alignment[0] = (unsigned long *)((unsigned long)pm_slaves_device_config[vi].raw_data_buf[0] & 0xfffffff0);
            if ((unsigned long)pm_slaves_device_config[vi].raw_data_buf[0] & 0xf)
            {
                pm_slaves_device_config[vi].raw_data_buf_alignment[0] = (unsigned long *)((unsigned long)pm_slaves_device_config[vi].raw_data_buf_alignment[0] + 16);
            }
            pm_slaves_device_config[vi].raw_data_buf_alignment[1] = (unsigned long *)((unsigned long)pm_slaves_device_config[vi].raw_data_buf[1] & 0xfffffff0);
            if ((unsigned long)pm_slaves_device_config[vi].raw_data_buf[1] & 0xf)
            {
                pm_slaves_device_config[vi].raw_data_buf_alignment[1] = (unsigned long *)((unsigned long)pm_slaves_device_config[vi].raw_data_buf_alignment[1] + 16);
            }

            pm_slaves_device_config[vi].scale_data_buf = (double *)malloc(sizeof(double) * pm_slaves_device_config[vi].buf_size);

            for (int vj = 0; vj < 2; ++ vj)
            {
                short result = DSA_AI_ContBufferSetup(pm_slaves_device_config[vi].card_handle, pm_slaves_device_config[vi].raw_data_buf_alignment[vj], pm_slaves_device_config[vi].buf_size, &pm_slaves_device_config[vi].buf_id_array[vj]);
                if (result != NoError)
                {
                    if (vj != 0)
                    {
                        // Reset buffer
                        DSA_AI_ContBufferReset(pm_slaves_device_config[vi].card_handle);
                    }
                    for (int vk = 0; vk < vj; ++ vk)
                    {
                        free(pm_slaves_device_config[vi].raw_data_buf[vk]);
                    }
                    free(pm_slaves_device_config[vi].scale_data_buf);
                    printf("\nFalied to perform DSA_AI_ContBufferSetup() for Master, error: %d", result);
                    return -12;
                }
            }
            pm_slaves_device_config[vi].is_set_buf = 1;
        }
    }

    return 0;
}

short fn_config_ai_event_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    // Master
    if (NULL != pm_master_device_config)
    {
        // Set AI buffer Ready event
        short result = DSA_AI_EventCallBack(pm_master_device_config->card_handle, 1, DBEvent, pm_master_device_config->callback_ai_buf_ready);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_AI_EventCallBack() for Master, error: %d", result);
            return -1;
        }
        pm_master_device_config->is_buf_ready_evt_set = 1;

        // Set AI done event
        result = DSA_AI_EventCallBack(pm_master_device_config->card_handle, 1, AIEnd, pm_master_device_config->callback_ai_done);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_AI_EventCallBack() for Master, error: %d", result);
            return -2;
        }
        pm_master_device_config->is_done_evt_set = 1;
    }

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            // Set AI buffer Ready event
            short result = DSA_AI_EventCallBack(pm_slaves_device_config[vi].card_handle, 1, DBEvent, pm_slaves_device_config[vi].callback_ai_buf_ready);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_AI_EventCallBack() for Slave, error: %d", result);
                return -11;
            }
            pm_slaves_device_config[vi].is_buf_ready_evt_set = 1;

            // Set AI done event
            result = DSA_AI_EventCallBack(pm_slaves_device_config[vi].card_handle, 1, AIEnd, pm_slaves_device_config[vi].callback_ai_done);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_AI_EventCallBack() for Slave, error: %d", result);
                return -12;
            }
            pm_slaves_device_config[vi].is_done_evt_set = 1;
        }
    }

    return 0;
}

short fn_start_ai_acquisition_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config)
{
    // Open file
    if (NULL != pm_master_device_config)
    {
        pm_master_device_config->file_writer = fopen(pm_master_device_config->file_name, "w");
        pm_master_device_config->is_file_open = 1;
    }
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            pm_slaves_device_config[vi].file_writer = fopen(pm_slaves_device_config[vi].file_name, "w");
            pm_slaves_device_config[vi].is_file_open = 1;
        }
    }

    // Read AI data, and the acquired raw data will be stored in the set buffer.
    // Note that Slave should be started before starting Master

    // Slaves
    if (dw_num_of_slaves > 0 && NULL != pm_slaves_device_config)
    {
        for (unsigned int vi = 0; vi < dw_num_of_slaves; ++ vi)
        {
            short result = DSA_AI_ContReadChannel(pm_slaves_device_config[vi].card_handle, pm_slaves_device_config[vi].chnl_cnt, 0, pm_slaves_device_config[vi].buf_id_array, pm_slaves_device_config[vi].all_data_count, 0, ASYNCH_OP);
            if (result != NoError)
            {
                printf("\nFalied to perform DSA_AI_ContReadChannel() for Slave, error: %d", result);
                return -11;
            }
            pm_slaves_device_config[vi].is_op_run = 1;
        }
    }

    // Master
    if (NULL != pm_master_device_config)
    {
        short result = DSA_AI_ContReadChannel(pm_master_device_config->card_handle, pm_master_device_config->chnl_cnt, 0, pm_master_device_config->buf_id_array, pm_master_device_config->all_data_count, 0, ASYNCH_OP);
        if (result != NoError)
        {
            printf("\nFalied to perform DSA_AI_ContReadChannel() for Master, error: %d", result);
            return -1;
        }
        pm_master_device_config->is_op_run = 1;
    }

    printf("\nAI operation is started, waiting trigger from the set trigger source...\n");
    if (NULL != pm_master_device_config && pm_master_device_config->is_gen_sw_trig)
    {
        // Generate software trigger for Master if the trigger source is set to software trigger
        printf("\nPress 'Enter' to generate software trigger for Master.");
        getchar();
        printf("Generating software trigger... ");
        DSA_TRG_SoftTriggerGen(pm_master_device_config->card_handle);
        printf("done\n");
    }
    return 0;
}

