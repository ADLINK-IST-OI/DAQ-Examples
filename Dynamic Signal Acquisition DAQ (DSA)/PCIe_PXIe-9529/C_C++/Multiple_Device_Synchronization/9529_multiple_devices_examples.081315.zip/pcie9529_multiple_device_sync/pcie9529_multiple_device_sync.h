#ifndef _PCIE9529_MULTIPLE_DEVICE_SYNC_H
#define _PCIE9529_MULTIPLE_DEVICE_SYNC_H

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "DSA-Dask.h"

typedef struct _device_config
{
    // Device configuration & status variables
    unsigned char is_reg_dev;
    unsigned short card_type;
    unsigned short card_num;
    unsigned short card_handle;

    // Timebase configuration variables
    unsigned short timebase_src;
    double sample_rate;
    double actual_rate;

    // Trigger configuration & status variables
    unsigned short trig_target;
    unsigned short trig_config;
    unsigned char is_gen_sw_trig;
    unsigned char is_set_ana_trig;
    unsigned long retrig_count;
    unsigned long trig_delay;
    unsigned short trig_out;
    unsigned char is_trig_out_connected;

    // Analog trigger configuration variables
    unsigned long ana_trig_src;
    unsigned long ana_trig_mode;
    double ana_trig_threshold;

    // PDN SYNC configuration & status variables
    unsigned short pdn_sync_type;
    unsigned long pdn_sync_path;
    unsigned short pdn_sync_status;
    unsigned char is_pdn_sync;

    // Channel configuration variables
    unsigned short chnl_cnt;
    unsigned short chnl_range;
    unsigned short chnl_config;

    // Data buffer & file variables
    unsigned long chnl_sample_count;
    unsigned long all_data_count;
    unsigned long buf_size;
    unsigned long *raw_data_buf[2];
    unsigned long *raw_data_buf_alignment[2];
    double *scale_data_buf;
    unsigned short buf_id_array[2];
    unsigned char is_set_buf;
    unsigned short file_format;
    char file_name[MAX_PATH];
    FILE *file_writer;
    unsigned char is_file_open;

    // AI opeation callback variables
    unsigned long callback_ai_done;
    unsigned long callback_ai_buf_ready;
    unsigned char is_done_evt_set;
    unsigned char is_buf_ready_evt_set;

    // AI operation status variables
    unsigned char is_op_run;
    unsigned long access_cnt;
    unsigned int buf_ready_idx;
    unsigned int buf_ready_cnt;
}
DEVICE_CONFIG, *P_DEVICE_CONFIG;

// Exit function
void fn_exit_handler(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Initial device structure function
void fn_init_master_struct(P_DEVICE_CONFIG pm_device_config, unsigned int dw_card_idx);
void fn_init_slave_struct(P_DEVICE_CONFIG pm_device_config, unsigned int dw_card_idx);

// Configure device structure function
void fn_config_master_struct(P_DEVICE_CONFIG pm_device_config);
void fn_config_slave_struct(P_DEVICE_CONFIG pm_device_config);

// Register device function
short fn_register_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Configure synchronization function
short fn_config_sync_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Start synchronzation function
short fn_start_sync_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Configure AI channel function
short fn_config_ai_channel_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Configure AI buffer function
short fn_config_ai_buffer_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Configure AI event callback function
short fn_config_ai_event_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

// Start AI acquisition function
short fn_start_ai_acquisition_master_slave(P_DEVICE_CONFIG pm_master_device_config, unsigned int dw_num_of_slaves, P_DEVICE_CONFIG pm_slaves_device_config);

#endif
